import java.io.File;


public class Teste {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File f = new File("teste.txt");
		if (f.exists())
		{
			System.out.println("Existe");
		}else
			System.out.println("nao existe");
		
	}

}
