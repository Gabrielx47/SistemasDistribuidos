import java.net.DatagramPacket;
import java.net.DatagramSocket;


public class ServidorArquivo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		try {
			// Classe java para trabalhar com multicast ou broadcast
			DatagramSocket mcs = new DatagramSocket(6001);// porta como
			System.out.println("Servidor de arquivo ativado(broadcast)!!!!");												// parametro
	
			while (true) {

				byte rec[] = new byte[256];
				DatagramPacket pkg = new DatagramPacket(rec, rec.length);
				mcs.receive(pkg);// recebendo dados enviados via broadcast
				ConexaoPrincipalArquivos cpa = new ConexaoPrincipalArquivos(pkg);
				cpa.start();
			}
		}

		catch (Exception e) {
			System.out.println("Erro: " + e.getMessage());
		}

	}

}
