import java.io.File;
import java.net.*;


public class ConexaoPrincipalArquivos extends Thread{

	private DatagramPacket pkg;

	public ConexaoPrincipalArquivos(DatagramPacket pkg) {
		this.pkg = pkg;
	}


	public void run(){
		
		try{
		String nmArquivo = new String(pkg.getData(), 0, pkg.getLength());
		
		File f = new File(nmArquivo);
		if (f.exists())
		{
			InetAddress IPAddress = pkg.getAddress();
			int port = pkg.getPort();			
			byte[] sendData = InetAddress.getLocalHost().getHostName().getBytes();
			DatagramPacket sendPacket = new DatagramPacket(sendData,
					sendData.length, IPAddress, port);
			
			new DatagramSocket().send(sendPacket);
		}
		}catch(Exception ex){
			System.out.println(ex.getMessage());
		}
	}
	
	
}
