import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.Scanner;


public class Cliente {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		try {
			Socket clientSocket = new Socket("127.0.0.1", 7000);
			DataOutputStream outToServer = new DataOutputStream(
					clientSocket.getOutputStream());			
			BufferedReader inFromServer = new BufferedReader(new InputStreamReader(
					clientSocket.getInputStream()));

			BufferedReader inFromUser = new BufferedReader(new InputStreamReader(
					System.in));
			String nmArquivo = inFromUser.readLine();
			
			outToServer.writeBytes(nmArquivo + "\n");

			String servidores = inFromServer.readLine();
			int qtdServidores = Integer.parseInt(servidores);
			if (qtdServidores > 0 )
			{
				ArrayList<MensagemRespostaServidorArquivo> lstHosts = new ArrayList<MensagemRespostaServidorArquivo>();
				System.out.println("Lista servidores que possuem o arquivo "+nmArquivo);
				for (int i = 0; i < qtdServidores; i++) {
					String nomeServidor = inFromServer.readLine();
					String ip = inFromServer.readLine();
					System.out.println((i+1)+" - Maquina: "+ nomeServidor+" - ip: "+ip);
					lstHosts.add(new MensagemRespostaServidorArquivo(ip, nomeServidor));
				}
				clientSocket.close();
				
				System.out.println("Escolha  o numero do servidor: ");
				int codServidor = new Scanner(System.in).nextInt();
				download(lstHosts.get(codServidor-1).getIp(), nmArquivo);
			}else{
				System.out.println("Arquivo n�o encontrado!!!");
				clientSocket.close();
			}
			
			
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		}

	
	}
	
	public static void download(String ip, String nmArquivo){
		try{
		// Criando arquivo que sera recebido pelo servidor
		FileOutputStream fileOut = new FileOutputStream("Cliente_"+nmArquivo);

		// Criando canal de transferencia
		Socket clientSocket = new Socket(ip, 6000);
		DataOutputStream outToServer = new DataOutputStream(
				clientSocket.getOutputStream());			
		InputStream socketIn = clientSocket.getInputStream();
		outToServer.writeBytes(nmArquivo + "\n");

		// Lendo o arquivo recebido pelo socket e gravando no
		// arquivo local
		System.out.println("Recebendo Arquivo: cliente_teste.txt");

		byte[] cbuffer = new byte[1024];
		int bytesRead;
		while ((bytesRead = socketIn.read(cbuffer)) != -1) {
			fileOut.write(cbuffer, 0, bytesRead);
		}
		fileOut.close();

		clientSocket.close();
		System.out.println("Arquivo Recebido: Arquivo: cliente_teste.txt");
		}catch(Exception ex){
			System.out.println(ex.getMessage());
		}
	}
	

}
