import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class ServidorPrincipal {

	public static void main(String[] args) {
		try {
			ServerSocket server = new ServerSocket(7000);
			System.out.println("Servidor principal ativado!!!");
			while (true) {
				Socket s = server.accept();
				ConexaoPrincipalCliente cp = new ConexaoPrincipalCliente(s);
				cp.start();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
