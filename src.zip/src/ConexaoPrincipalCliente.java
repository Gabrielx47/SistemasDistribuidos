import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.ArrayList;

public class ConexaoPrincipalCliente extends Thread {
	private Socket s;

	public ConexaoPrincipalCliente(Socket s) {
		this.s = s;
	}

	public void run() {
		ArrayList<MensagemRespostaServidorArquivo> lstMensagens = new ArrayList<MensagemRespostaServidorArquivo>();
		try {
			BufferedReader inFromClient = new BufferedReader(
					new InputStreamReader(s.getInputStream()));
			DataOutputStream outToClient = new DataOutputStream(
					s.getOutputStream());

			String nmArquivo = inFromClient.readLine();
			
			// Enviando broadcast para os servidores de arquivo
			byte[] b = nmArquivo.getBytes();
			InetAddress addr = InetAddress.getByName("255.255.255.255");
			DatagramPacket pkg = new DatagramPacket(b, b.length, addr,6001);
			DatagramSocket ds = new DatagramSocket();
			ds.send(pkg);//enviando pacote broadcast

			//esperando respostas dos servidores de arquivo
			ds.setSoTimeout(10000);
			try{			
				byte rec[] = new byte[256];
				while (true) {
					pkg = new DatagramPacket(rec, rec.length);
					ds.receive(pkg);// recebendo dados enviados via broadcast
					String nmMaquina = new String(pkg.getData(), 0, pkg.getLength());
					lstMensagens.add(new MensagemRespostaServidorArquivo(pkg.getAddress().toString().replaceAll("/", ""), nmMaquina));
				}
				
			}catch(SocketTimeoutException te){
				System.out.println("Acabou o tempo de respostas");
			}
			outToClient.writeBytes(lstMensagens.size()+"\n");
			//Enviar as respostas para o cliente
			for (MensagemRespostaServidorArquivo m : lstMensagens) {
				outToClient.writeBytes(m.getNomeMaquina()+"\n");
				outToClient.writeBytes(m.getIp()+"\n");
			}
			
			s.close();
			
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		}

	}

}
