
public class MensagemRespostaServidorArquivo {
	private String ip;
	private String nomeMaquina;
	public MensagemRespostaServidorArquivo(String ip, String nomeMaquina) {
		this.ip = ip;
		this.nomeMaquina = nomeMaquina;
	}
	public String getIp() {
		return ip;
	}
	public String getNomeMaquina() {
		return nomeMaquina;
	}

	
	
}
